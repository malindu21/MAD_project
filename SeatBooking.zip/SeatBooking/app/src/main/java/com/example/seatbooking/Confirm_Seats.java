package com.example.seatbooking;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Confirm_Seats extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm__seats);
    }
}
